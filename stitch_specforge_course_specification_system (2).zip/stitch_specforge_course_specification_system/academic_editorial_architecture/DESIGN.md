---
name: Academic Editorial Architecture
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#40484b'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#70787c'
  outline-variant: '#c0c8cb'
  surface-tint: '#306576'
  primary: '#003441'
  on-primary: '#ffffff'
  primary-container: '#0f4c5c'
  on-primary-container: '#87bbce'
  inverse-primary: '#9acee1'
  secondary: '#006781'
  on-secondary: '#ffffff'
  secondary-container: '#8fdfff'
  on-secondary-container: '#00647d'
  tertiary: '#223043'
  on-tertiary: '#ffffff'
  tertiary-container: '#38465a'
  on-tertiary-container: '#a5b4cc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b6ebfe'
  primary-fixed-dim: '#9acee1'
  on-primary-fixed: '#001f28'
  on-primary-fixed-variant: '#114d5d'
  secondary-fixed: '#b9eaff'
  secondary-fixed-dim: '#81d1f0'
  on-secondary-fixed: '#001f29'
  on-secondary-fixed-variant: '#004d62'
  tertiary-fixed: '#d5e3fd'
  tertiary-fixed-dim: '#b9c7e0'
  on-tertiary-fixed: '#0d1c2f'
  on-tertiary-fixed-variant: '#3a485c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  data-mono:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-dense: 0.75rem
  margin: 2rem
  margin-compact: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system is tailored for higher-education curriculum authoring, matrix validation, and institutional governance. It balances the editorial clarity of document workspaces like Notion with the rigorous efficiency and dense metadata tracking found in Linear. 

The aesthetic is functional, authoritative, and calm. Designed for professors, committee reviewers, and academic administrators engaged in intense cognitive work, the interface eliminates frivolous ornament, bright saturated washes, and heavy drop shadows in favor of balanced typography, crisp division lines, and tabular information density.

Key principles:
- **Calm & Scholarly**: Visual noise is systematically reduced. Chrome recedes to keep syllabus structures, accreditation criteria, and learning outcome mappings in focus.
- **Editorial Precision**: Generous readable line lengths for prose specifications, paired with dense, mono-aligned data grids for credit distribution and course matrices.
- **Decisive Governance**: Critical workflow gates (e.g., Department Sign-off, Senate Approval, Prerequisite Violations) utilize clear semantic accents without aggressive visual distraction.

## Colors

The palette establishes an intellectual, trustworthy canvas using deep academic teal and balanced slate neutrals.

- **Primary (`#0F4C5C`)**: Deep Academic Teal. Applied to key interactive controls, selected navigation items, primary workflow CTAs, and active document statuses.
- **Secondary (`#0E7490`)**: Cyan Slate. Used for secondary focus rings, metadata highlights, active review filters, and progress metrics.
- **Tertiary (`#334155`)**: Slate Dark. Used for high-emphasis sub-headers, table labels, and structural anchors.
- **Neutral (`#64748B`)**: Cool Slate. Drives low-emphasis text, secondary breadcrumbs, and neutral rule borders.

### Canvas & Structural Backgrounds
- **App Canvas**: `#F8FAFC` (Slate 50) provides a soft, eye-resting foundation that avoids harsh white glare during long review sessions.
- **Document / Panel Surface**: `#FFFFFF` (Pure White) creates crisp spatial separation for cards, review sheets, and editor blocks.
- **Border / Hairlines**: `#E2E8F0` (Slate 200) serves as the primary structural boundary for tables, sidebars, and form fields.

### Status System
- **Valid / Approved**: Emerald Green (`#047857`), surface tint (`#ECFDF5`). Indicates compliant credit tallies and signed-off syllabi.
- **Attention / In Review**: Warm Amber (`#B45309`), surface tint (`#FFFBEB`). Highlights pending approvals and missing competency indicators.
- **Discrepancy / Error**: Crimson Red (`#B91C1C`), surface tint (`#FEF2F2`). Highlights circular prerequisites, unmet credit hours, or accreditation gaps.

## Typography

The typography leverages **Plus Jakarta Sans** for document headings and section framing to bring modern academic authority, combined with **Inter** for dense data representations, forms, and editorial reading.

- **Tabular Numerals**: Apply `font-feature-settings: "tnum" 1` across all curriculum matrices, credit totals, course IDs, and accreditation indices.
- **Reading Measure**: Limit course description and narrative outcome sections to a strict maximum width of `65ch` to maintain sustained focus.
- **Hierarchy Rules**: Use semibold weight sparingly—primarily for field headers, status labels, and course identifiers—reserving bold for section document titles.

## Layout & Spacing

The layout is built for high-resolution desktop workflow productivity, prioritizing 1366px to 1920px viewports while maintaining resilient responsiveness down to smaller screens.

### Desktop-First Structural Layout
- **Left Rail (Persistent, 240px–280px)**: Department hierarchy, course inventory tree, and global workflow stages.
- **Center Canvas (Flexible, Max 1080px)**: The primary drafting document or specification sheet, using the white surface on soft slate canvas metaphor.
- **Right Inspector (Collapsible, 320px–380px)**: Contextual audit pane, Bloom's taxonomy validator, peer review comments, and prerequisite check.

### Grid Rhythm & Adapting
- **Work Area**: 12-column grid utilizing `gutter: 1.5rem` for standard workspaces, and `gutter-dense: 0.75rem` for data-heavy course mapping tables.
- **Table Density**: Matrix views (Course Learning Outcomes vs. Program Outcomes) drop cell padding to `space-xs` vertically and `space-sm` horizontally to maximize visible cells without horizontal pagination.
- **Breakpoints**:
  - `1440px+`: Three-column layout fully expanded with uncollapsed inspector.
  - `1024px–1439px`: Right inspector moves to overlay drawer; center canvas adapts to available width.
  - `< 1024px`: Left navigation collapses to an icon bar or drawer.

## Elevation & Depth

This system intentionally departs from diffuse layered shadows, relying instead on **low-contrast outlines** and **tonal planes** to organize visual depth.

- **Flat Baseline**: The canvas (`#F8FAFC`) hosts pure white document surfaces (`#FFFFFF`) defined strictly by a 1px solid border (`#E2E8F0`).
- **Floating Overlays (Dropdowns, Menus, Popovers)**: Elevated using an ultra-subtle ambient shadow: `0 4px 12px -2px rgba(15, 23, 42, 0.06), 0 2px 4px -1px rgba(15, 23, 42, 0.04)`, reinforced by an explicit `#E2E8F0` border.
- **Modal Dialogues (Curriculum Sign-Off, Freeze Baseline)**: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)` over a soft backdrop scrim (`rgba(15, 23, 42, 0.35)` with a 2px blur).
- **Interactive Hover**: Surfaces do not float up on hover. Interactive rows and list items change tone to `#F1F5F9` without altering elevation or borders.

## Shapes

The interface embraces a restrained geometric discipline with **Soft (Level 1)** roundedness. This communicates structure and aligns with the editorial aesthetic.

- **Base Radius (0.25rem / 4px)**: Input fields, table row highlight containers, tags, and small badges.
- **Medium Radius (0.5rem / 8px)**: Cards, document containers, modals, and panel sheets.
- **Interactive Pills**: Forbidden except for high-contrast workflow counters (e.g., unresolved comment badges) which use circular shapes. Buttons and form elements remain firmly structured at 4px–6px radius.

## Components

### Buttons
- **Primary**: Solid `#0F4C5C` fill, `#FFFFFF` text, subtle 1px border (`#0D3B47`). Hover: `#0C3E4B`. Active: `#0A333E`.
- **Secondary / Outline**: `#FFFFFF` surface, `#334155` text, 1px border (`#CBD5E1`). Hover: `#F8FAFC` background.
- **Subtle / Ghost**: No border, `#475569` text. Hover: `#F1F5F9` background. Used for table action menus and inline toolbar triggers.
- **Destructive**: Solid `#B91C1C` fill or ghost state with `#B91C1C` text for irreversible actions (e.g., "Decommission Course").

### Badges & Status Chips
- Height: 22px, font: `label-sm`, padding: `2px 8px`, border radius: `4px`.
- **Draft**: `#F1F5F9` background, `#475569` text, `#E2E8F0` border.
- **HOD Review**: `#FFFBEB` background, `#92400E` text, `#FDE68A` border.
- **Senate Approved**: `#ECFDF5` background, `#065F46` text, `#A7F3D0` border.
- **Prerequisite Flag**: `#FEF2F2` background, `#991B1B` text, `#FECACA` border.

### Input Fields & Textareas
- Crisp 1px `#CBD5E1` border on `#FFFFFF` surface.
- Focus: 1px border `#0F4C5C` with a matching 2px box-shadow ring (`rgba(15, 76, 92, 0.15)`).
- Error state: `#B91C1C` border with red ring highlight.
- Monospace mode: For credit distribution formulas and course numbering schemes.

### Data Tables & Curriculum Matrices
- **Headers**: Sticky top, `#F8FAFC` background, uppercase `label-sm` text with `#64748B` color, 1px bottom border (`#E2E8F0`).
- **Cells**: 40px row height for standard data, 1px horizontal dividers (`#F1F5F9`).
- **Matrix Cross-References**: Centered alignment with clean binary indicators (e.g., filled check mark in `#0F4C5C` vs. empty dash in `#CBD5E1`).

### Step Navigation / Stepper
- Horizontal bar indicating workflow stages (Drafting → Faculty Review → Board of Studies → Academic Council).
- Linear connection rules: 2px solid lines (`#E2E8F0` pending, `#0F4C5C` completed).
- Step Nodes: 28px square with rounded corners (4px), displaying tabular numbers or an approval check mark.

### Inline Comments & Revision Callouts
- Left-bordered editorial callout style (3px solid `#0E7490`), pure white card background, nested within the document canvas margin for faculty review notes.