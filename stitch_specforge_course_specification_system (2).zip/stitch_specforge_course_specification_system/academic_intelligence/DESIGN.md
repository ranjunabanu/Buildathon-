---
name: Academic Intelligence
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#6b38d4'
  on-secondary: '#ffffff'
  secondary-container: '#8455ef'
  on-secondary-container: '#fffbff'
  tertiary: '#404762'
  on-tertiary: '#ffffff'
  tertiary-container: '#585f7b'
  on-tertiary-container: '#d3dafb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#bec5e5'
  on-tertiary-fixed: '#131a33'
  on-tertiary-fixed-variant: '#3e4660'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 20px
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative, precise, and high-clarity environment tailored for higher education curriculum planning, institutional accreditation, and cross-departmental syllabus analytics. The aesthetic merges executive SaaS professionalism with academic rigor: deep collegiate foundations elevated by modern, data-dense ergonomics.

The visual style is **Corporate / Modern** augmented with subtle atmospheric depth and micro-surfacing. Interfaces project structural integrity and intellectual clarity, eliminating visual noise in favor of high-contrast typographic cadence, crisp structural borders, and purposeful chromatic status feedback.

Interactions must feel instantaneous, definitive, and trustworthy—evoking institutional prestige and forward-thinking curriculum architecture.

## Colors

The palette establishes an authoritative visual anchor while delivering sharp data comprehension across complex curriculum trees.

### Roles & Intent
- **Primary (`#4F46E5` / `#6366F1`)**: Vibrant Electric Indigo. Directs actionable focus, high-tier navigation highlights, and interactive states.
- **Secondary (`#8B5CF6`)**: Refined Violet. Applied to analytical summaries, predictive curriculum pathways, and high-level academic metric callouts.
- **Tertiary (`#0B132B` / `#0F172A`)**: Deep Collegiate Navy. Operates as primary typography anchor, high-elevation headers, and structural sidebars.
- **Neutrals**:
  - Canvas Base: `#F8FAFC`
  - Container Surfaces: `#FFFFFF`
  - Subtle Borders & Dividers: `#E2E8F0`
  - Secondary Borders: `#CBD5E1`
  - Subdued Text / Metadata: `#64748B`
  - High-Contrast Text: `#0F172A`
- **Semantic Indicators**:
  - Validated / Approved: `#10B981` (Emerald) with soft tinted fill `#ECFDF5`
  - Audit Advisory / Warning: `#F59E0B` (Amber) with soft tinted fill `#FFFBEB`
  - Error / Blocker: `#EF4444` (Crimson) with soft tinted fill `#FEF2F2`

All interactive contrast ratios maintain strict compliance with WCAG AA (minimum 4.5:1 against respective surface backgrounds).

## Typography

Typography prioritizes structural clarity and scanability across high-density curriculum frameworks.

- **Plus Jakarta Sans**: Handles primary brand narrative, headers, tables, and standard copy. Its open apertures and balanced geometric structure maintain legibility across both dense audit matrices and high-level summary cards.
- **JetBrains Mono**: Dedicated to course codes (e.g., `CS-402`, `MATH-108`), accreditation identifiers, metric percentages, and technical audit logs. This reinforces precision and programmatic credibility.

All uppercase labels must utilize `label-caps` with expanded tracking (`0.06em`) to ensure legibility when rendered in dense table headers or audit pill tags.

## Layout & Spacing

The layout operates on an 8pt architectural rhythm within a 12-column fluid grid system, engineered to scale between macro dashboard analytics and dense curricular matrices.

### Breakpoints & Fluid Adaptations
- **Desktop (≥ 1280px)**: 12-column structure with `margin-lg` (48px) and `gutter` (24px). Accommodates dual side-panels (tree navigation + metadata inspector) surrounding the central content spine.
- **Tablet (768px – 1279px)**: 8-column layout with `margin` (32px) and `gutter-sm` (16px). Secondary telemetry panels collapse into off-canvas sliding drawers.
- **Mobile (< 768px)**: 4-column layout with `margin-sm` (16px) and `gutter-sm` (16px). Curriculum nodes stack vertically with full-bleed cards.

Use `space-xs` and `space-sm` for inline status badges, pill tags, and input internal padding. Reserve `space-lg` and `space-xl` for container sectioning and module separation to maintain an uncluttered executive demeanor.

## Elevation & Depth

Visual hierarchy is maintained primarily via structural borders (`#E2E8F0`) combined with ultra-subtle ambient indigo-tinted drop shadows to avoid muddy visuals.

- **Flat Surface (Level 0)**: Background canvas (`#F8FAFC`). No elevation or border.
- **Card / Module (Level 1)**: Pure white background (`#FFFFFF`), 1px crisp outline in `#E2E8F0`, and ambient drop shadow: `0 1px 3px 0 rgba(11, 19, 43, 0.04), 0 1px 2px -1px rgba(11, 19, 43, 0.02)`.
- **Interactive Hover / Card Focus (Level 2)**: Border transitions to `#CBD5E1`, with elevation lifting to: `0 4px 6px -1px rgba(11, 19, 43, 0.06), 0 2px 4px -2px rgba(11, 19, 43, 0.03)`.
- **Dropdowns / Flyout Panels (Level 3)**: `#FFFFFF` surface with crisp border `#E2E8F0` and diffuse elevation: `0 10px 15px -3px rgba(11, 19, 43, 0.08), 0 4px 6px -4px rgba(11, 19, 43, 0.04)`.
- **Modals / Critical Overlays (Level 4)**: Backdrop obscured with `rgba(11, 19, 43, 0.45)` with `backdrop-filter: blur(4px)`. Overlay container features high-diffuse shadow: `0 20px 25px -5px rgba(11, 19, 43, 0.12), 0 8px 10px -6px rgba(11, 19, 43, 0.06)`.

## Shapes

The design system adopts a balanced, contemporary rounded corner schema (`roundedness: 2`).

- **Base Elements (0.5rem / 8px)**: Standard inputs, actionable buttons, chip badges, and menu items.
- **Panels & Tables (1rem / 16px)**: Medium internal modular blocks and popover containers.
- **High-Level Cards (`rounded-xl` / 1.5rem / 24px)**: Curriculum summary cards, analytics widgets, and structural modal sheets.

This avoids juvenile over-rounding while softening the analytical visual weight of enterprise tables and dense node structures.

## Components

### Buttons
- **Primary**: Solid Indigo (`#4F46E5`), text `#FFFFFF`, rounded 8px. Hover state shifts to `#4338CA` with an active state scale down (`0.98`).
- **Secondary**: Surface `#FFFFFF`, border 1px solid `#CBD5E1`, text `#0F172A`. Hover transitions background to `#F8FAFC` and border to `#94A3B8`.
- **Tertiary / Ghost**: Transparent fill, text `#4F46E5`. Hover applies `#EEF2FF` fill.
- **Destructive**: Background `#EF4444`, text `#FFFFFF`. Hover shifts to `#DC2626`.

### Chips & Semantic Status Badges
- Rendered using `label-caps` typography with 8px radius and strict 6px horizontal padding.
- **Approved / Validated**: Emerald `#10B981` text, `#ECFDF5` background, `#A7F3D0` subtle border.
- **Audit Advisory**: Amber `#D97706` text, `#FFFBEB` background, `#FDE68A` subtle border.
- **Error / Blocker**: Crimson `#DC2626` text, `#FEF2F2` background, `#FECACA` subtle border.
- **Telemetry / Course Code Badge**: Monospace font, `#0F172A` text, `#F1F5F9` background, `#E2E8F0` border.

### Cards
- Base styling: White surface (`#FFFFFF`), `rounded-xl` (24px), framed by 1px border `#E2E8F0`. Padding uses `space-lg` (24px).
- Internal hierarchy separates header, body, and action footer using subtle divider lines (`#F1F5F9`).

### Input Fields
- White fill, 1px border `#CBD5E1`, rounded 8px, height 40px, font `body-md`.
- Focus state applies a crisp outline: 1px `#4F46E5` border with an outer focus ring `box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2)`.

### Checkboxes & Radios
- Size 18x18px, border 1.5px `#94A3B8`, rounded 4px for checkboxes, circular for radios.
- Checked state transitions immediately to `#4F46E5` with sharp white glyphs.

### Lists & Curriculum Trees
- Row items possess alternating hover states using `#F8FAFC`.
- Tree hierarchy nodes are linked via 1.5px continuous guide lines (`#E2E8F0`) with trailing monospace status chips indicating validation compliance scores.