---
name: SpecForge Neural Aurora
colors:
  surface: '#10131c'
  surface-dim: '#10131c'
  surface-bright: '#363943'
  surface-container-lowest: '#0b0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#272a34'
  surface-container-highest: '#32343f'
  on-surface: '#e0e2ef'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e0e2ef'
  inverse-on-surface: '#2d303a'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#5de6ff'
  on-secondary: '#00363e'
  secondary-container: '#00cbe6'
  on-secondary-container: '#00515d'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#a2eeff'
  secondary-fixed-dim: '#2fd9f4'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#004e5a'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#10131c'
  on-background: '#e0e2ef'
  surface-variant: '#32343f'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  mono-metric:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.02em
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-caps:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-precision, mission-critical workspace tailored for regulatory architects, compliance engineers, and AI governance operators. The interface commands institutional authority through deep astronomical voids, cold luminescent telemetry, and razor-sharp data density.

The aesthetic fuses **Futuristic Precision Minimalism** with controlled **Glassmorphic Cybernetics**. It eschews decorative clutter in favor of tactical feedback: dark graphite planes layered with 1px translucent boundaries, selective bioluminescent accents, and ambient neural halos that signal real-time cognitive processing without sacrificing operational clarity.

- **Primary Persona:** Enterprise AI Safety Engineers, Chief Compliance Officers, and Lead Systems Architects.
- **Emotional Intent:** Absolute analytical rigor, deep control, continuous verification, and futuristic calm.
- **Visual Tension:** Pitch-black structural voids (#080B14) balanced against microscopic, vibrant spectral indicators that immediately isolate anomalies.

## Colors

The palette operates on calibrated luminescence tiers over a zero-light substrate. It reserves active color exclusively for spatial focus, telemetry metrics, and deterministic verification states.

### Core Canvas & Structural Tiers
- **Void Canvas (`#080B14`):** Default root canvas background, absorbing background scatter.
- **Graphite Base (`#111827`):** Primary surface for structural panels, rails, and application headers.
- **Graphite Elevated (`#161F30`):** Secondary container surface for grouped modules, telemetry pods, and data tables.
- **Graphite Overlay (`#1E293B`):** Tertiary interactive plane for flyouts, dialogs, popovers, and elevated hover states.

### Neural Chromatics
- **Electric Violet (`#8B5CF6`):** The primary cognitive engine accent. Used for state orchestration, core AI interactions, active selection rings, and high-tier neural nodes.
- **Luminous Cyan (`#22D3EE`):** The secondary tactical accent. Governs active data streams, system telemetry, scanning reticles, and sub-surface focus indicators.
- **Neural Aurora Blend:** A subtle composite linear gradient `linear-gradient(135deg, rgba(139, 92, 246, 0.15) 0%, rgba(34, 211, 238, 0.08) 100%)` used strictly for elevated hero modules and operational milestones.

### State & Telemetry Matrix
- **Emerald Green (`#10B981`):** Verified compliance, passed test vectors, certified neural pipelines.
- **Amber Warning (`#F59E0B`):** Threshold drifts, probabilistic hallucinations, heuristic warnings.
- **Rose Error (`#F43F5E`):** Critical compliance failures, safety policy violations, hard gate stops.
- **Muted Slate (`#64748B`):** Inactive parameters, peripheral metadata, grid rulers, and unselected tracks.

## Typography

The typographic hierarchy balances structural authority, sustained legibility during dense audits, and precise tabular alignments.

- **Plus Jakarta Sans (Headlines):** Brings sculptural, architectural geometry to structural headings and KPI overviews without compromising professional tone.
- **Inter (Body & Operational Prose):** Provides high-efficiency screen rendering for parameter logs, regulatory prose, policy declarations, and complex multi-line audits.
- **JetBrains Mono (Telemetry, Verification & Data Codes):** Anchors audit IDs, neural latency counters, hash validations, matrix bounds, and real-time inference telemetry. Enforces horizontal predictability in vertical listings.

### Rendering Directives
- Numeric counters and tabular datasets must consistently activate tabular figures (`font-variant-numeric: tabular-nums lining-nums`).
- Code labels and status indicators use uppercase styling paired with expanded tracking (`0.04em` to `0.08em`) to guarantee quick peripheral scanning.

## Layout & Spacing

This design system uses a strict **High-Density Fluid Grid** engineered for multi-monitor command layouts and mission-critical operations. Spacing is tight and mathematical to preserve vertical viewport utility while maintaining visual order.

### Grid Anatomy
- **Desktop (1280px+):** 12-column adaptive fluid grid with `1.5rem` gutters and `2rem` outer safe margins. Minimum workspace width is `1280px`; above `1920px`, the operational field dynamically scales column tracks with locked sidebars.
- **Tablet (768px - 1279px):** 8-column layout with `1rem` gutters and `1.5rem` side margins. Peripheral panels auto-collapse into flyout panels.
- **Mobile (<768px):** 4-column column-stacked layout with `1rem` margins. Complex matrix charts shift to sequential card views with horizontal data reels.

### Spacing Principles
- Gaps between interconnected controls (such as chained boolean filters) lock to `space-xs` (4px).
- Internal component pad sets scale between `space-sm` (8px) for compact table cells and `space-md` (12px) for form modules.
- Major visual sectioning within panels scales between `space-lg` (20px) and `space-xl` (32px).

## Elevation & Depth

Visual depth is achieved through **Surface Stacking, Chromatic Outlines, and Neural Aurora Radiance** rather than traditional drop shadows.

### Atmospheric Tiers
1. **Tier 0 (Root Bed):** `#080B14` flat background with an optional subtle vector grid pattern (`rgba(255, 255, 255, 0.02)` 24px step).
2. **Tier 1 (Panels & Frames):** `#111827` surface enclosed with a 1px border of `rgba(255, 255, 255, 0.07)`.
3. **Tier 2 (Interactive Tiles & Tables):** `#161F30` surface with `backdrop-filter: blur(12px)` and a hybrid dual-stroke: 1px border `rgba(34, 211, 238, 0.12)` transitioning to `rgba(139, 92, 246, 0.08)` on the opposite diagonal.
4. **Tier 3 (Floating HUDs & Modals):** `#1E293B` at 92% opacity, `backdrop-filter: blur(24px)`, bounded by a 1px `rgba(255, 255, 255, 0.18)` outline.

### Neural Aurora Bloom
Interactive components emit calibrated chromatic blooms rather than gray shadows:
- **Violet Glow (Focus/Active):** `0 0 0 1px rgba(139, 92, 246, 0.6), 0 0 24px -4px rgba(139, 92, 246, 0.35)`
- **Cyan Flare (Telemetry/Hover):** `0 0 0 1px rgba(34, 211, 238, 0.5), 0 0 20px -4px rgba(34, 211, 238, 0.3)`
- **Error Halo (Violations):** `0 0 0 1px rgba(244, 63, 94, 0.6), 0 0 18px -2px rgba(244, 63, 94, 0.3)`

## Shapes

The design system maintains a structured, architectural contour philosophy using deliberate, precise radii:

- **Standard Elements (8px / `0.5rem`):** Buttons, input fields, dropdown trigger targets, code snippets, and badge hulls.
- **Large Containers (12px / `0.75rem`):** Analytical cards, data tables, parameter inspectors, charts, and contextual drawers.
- **Micro-Indicators (4px / `0.25rem`):** Checkbox checks, progress track handles, and sub-atomic metric chips.
- **Pill (Full Round):** Exclusively reserved for execution status pills (e.g., live telemetry streaming dots) to instantly contrast against structural UI elements.

## Components

### Buttons
- **Primary (Neural Engine):** Gradient background from `#8B5CF6` to `#6D28D9`, solid `#FFFFFF` text (`Inter`, 13px, weight 600). Encased in a 1px border of `rgba(255, 255, 255, 0.25)`. Hover triggers violet luminescence (`0 0 20px rgba(139, 92, 246, 0.5)`).
- **Secondary (Tactical Cyan):** Background `rgba(34, 211, 238, 0.08)`, text `#22D3EE`, border `1px solid rgba(34, 211, 238, 0.3)`. Hover transitions to `rgba(34, 211, 238, 0.16)` and border `rgba(34, 211, 238, 0.6)`.
- **Ghost (Graphite Outline):** Transparent background, text `#94A3B8`, border `1px solid rgba(255, 255, 255, 0.1)`. Active states turn text to `#FFFFFF` with surface `#1E293B`.

### Badges & Status Chips
- Monospaced badges styled with `JetBrains Mono` at `11px`.
- Structured as high-contrast pills or 4px rounded rectangles with semi-opaque backgrounds:
  - *Pass:* Text `#10B981`, background `rgba(16, 185, 129, 0.1)`, border `1px solid rgba(16, 185, 129, 0.3)`.
  - *Warning:* Text `#F59E0B`, background `rgba(245, 158, 11, 0.1)`, border `1px solid rgba(245, 158, 11, 0.3)`.
  - *Critical:* Text `#F43F5E`, background `rgba(244, 63, 94, 0.1)`, border `1px solid rgba(244, 63, 94, 0.3)`.

### Input Fields & Controls
- **Text Inputs:** Height 36px, background `#111827`, border `1px solid rgba(255, 255, 255, 0.12)`, text `#F8FAFC`. Placeholder in `#475569`. Focus activates a 1px border in `#22D3EE` alongside a cyan ambient ring.
- **Checkboxes & Radios:** 16x16px base, background `#111827`, border `1px solid rgba(255, 255, 255, 0.2)`. Selected state fills with `#8B5CF6`, deploying an internal white icon.

### Cards & Telemetry Pods
- Enclosed modules with `#161F30` backgrounds and 12px rounded corners.
- Surfaces feature a delicate top-edge 1px highlight: `linear-gradient(90deg, rgba(139, 92, 246, 0.4) 0%, rgba(34, 211, 238, 0.4) 50%, transparent 100%)`.

### Neural Compliance Vectors (Specialized Domain Components)
- **Model Drift Radar:** Multi-axis SVG radar visualizer featuring translucent purple fills (`rgba(139, 92, 246, 0.25)`) and `#22D3EE` stroke paths.
- **Policy Gate Matrix:** Tabular telemetry lists displaying policy IDs in `JetBrains Mono`, paired with mini-histogram run charts and micro-pulsing status beacons.