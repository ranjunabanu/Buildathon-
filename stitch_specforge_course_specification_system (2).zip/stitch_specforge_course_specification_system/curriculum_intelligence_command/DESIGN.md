---
name: Curriculum Intelligence Command
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-telemetry:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style
The design system manifests an authoritative, ultra-premium executive command atmosphere engineered for higher-education leadership, provosts, deans, and academic intelligence officers. The brand aesthetic merges the intellectual gravity of premier academic institutions with the hyper-precise, predictive telemetry of next-generation artificial intelligence platforms.

The visual ethos blends **Corporate / Modern** rigor with selective **Glassmorphism** and high-precision data display. It avoids casual SaaS tropes, instead conveying rigorous stewardship, institutional integrity, and computational foresight through:
- Razor-sharp structural alignment and expansive, deliberate negative space.
- Dense, information-rich analytical views contrasted against crisp, high-clarity surfaces.
- Targeted luminescence: luminous intelligence indicators and status accents anchored by deep structural slate and obsidian frames.

## Colors
The color architecture operates on a high-clarity dualism: a light, crystalline analytical canvas framed by deep, authoritative executive chrome.

### Primary Role & Accents
- **Primary Indigo (`#4F46E5` / `#6366F1`)**: Represents synthesized intelligence, primary system actions, active navigational states, and foundational curriculum graphs.
- **Secondary Cyan Intelligence (`#06B6D4`)**: Reserved for automated AI discovery, real-time telemetry, semantic drift markers, and machine-suggested learning paths.
- **Tertiary Emerald Compliance (`#10B981`)**: Signals accreditation benchmarks met, verified credit transfers, and positive institutional alignment.
- **Advisory Amber (`#F59E0B`)**: Denotes non-critical pedagogical warnings, prerequisite warnings, or pending state board approvals.
- **Critical Rose (`#F43F5E`)**: Strictly used for critical curriculum blockers, accreditation deficiencies, and degree-audit failures.

### Neutral & Surface Foundation
- **Celestial Obsidian (`#090D16`)**: Defines command-tier application rails, persistent headers, and executive workspace shell contexts.
- **Slate Frame (`#0F172A`)**: Base neutral for deep navigation bars, terminal views, and primary typography in light surface modes.
- **Canvas Base (`#F8FAFC`)**: The master background plane providing optimal contrast for visual charts and document matrices.
- **Pure Surface (`#FFFFFF`)**: Card surfaces, active work panes, floating modals, and interactive data grid cells.
- **Subtle Borders (`#E2E8F0` / dark-tier `#1E293B`)**: Ultra-refined bounding lines maintaining strict spatial boundaries without visual weight.

## Typography
The system employs **Plus Jakarta Sans** for primary human-scale communication—chosen for its modern geometric architecture, pristine legibility at scale, and polished executive authority. 

For real-time telemetry, model confidence ratios, curriculum taxonomy codes (e.g., `CIP-11.0701`, `ABET-EAC-CRITERION-3`), and numeric audits, the system mandates **JetBrains Mono**. This establishes immediate structural contrast between qualitative pedagogical insights and quantitative machine evaluations.

### Typographic Rules
- Numerics within all tables, analytics tiles, and status readouts must utilize tabular numerals via `font-variant-numeric: tabular-nums`.
- Monospace tokens must strictly maintain uppercase transformation when representing institutional or governmental taxonomy codes.
- Headlines maintain tightened negative letter spacing to project density and executive precision.

## Layout & Spacing
The layout follows a strict mathematical 8pt baseline grid with an integrated 12-column fluid grid system across executive analytics dashboards.

### Grid & Breakpoints
- **Desktop (>= 1440px)**: 12 columns, `margin: 2rem`, `gutter: 1.5rem`. Accommodates dual persistent side-rails (Intelligence Index navigation left, Model Telemetry context right) with an elastic central canvas.
- **Tablet / Compact Desktop (1024px – 1439px)**: 8 columns, `margin: 1.5rem`, `gutter: 1rem`. Right contextual inspection drawer collapses to an overlay sheet.
- **Mobile (< 1023px)**: 4 columns, `margin: 1rem`, `gutter: 1rem`. Complex multi-axis charts collapse into stacked metric summaries and scrollable horizontal matrix rows.

### Spatial Discipline
Internal component spacing emphasizes clean grouping: micro gaps (`space-xs` and `space-sm`) bind atomic units (chips, metric units, inputs), while structural intervals (`space-lg` and `space-xl`) separate distinct analytical domains and curriculum pathways.

## Elevation & Depth
This design system avoids high-blur, non-directional shadow washes, relying instead on **low-contrast micro-elevation**, crisp 1px structural framing, and **selective glassmorphism**.

### Depth Layers
- **Base Canvas (Level 0)**: Unadorned `#F8FAFC` plane, visually framing elevated panels.
- **Panel Surface (Level 1)**: Pure white `#FFFFFF` surface with an ultra-fine border (`1px solid #E2E8F0`) and an ambient, whisper-light micro-shadow (`0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`).
- **Interactive Elevated (Level 2)**: Hover states, draggable graph nodes, and detached cards use a subtle double shadow tinted with slate (`0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`).
- **Intelligence Overlay & Modals (Level 3)**: Executive command palettes and AI insight drawers use backdrop blur (`backdrop-filter: blur(16px)`), a semi-translucent substrate (`rgba(255, 255, 255, 0.88)` in light context, `rgba(9, 13, 22, 0.85)` in dark context), and an elevated drop shadow (`0 20px 25px -5px rgba(9, 13, 22, 0.12), 0 8px 10px -6px rgba(9, 13, 22, 0.06)`).
- **Luminous Edge Highlighting**: When an AI recommendation or accreditation conflict is active, the component utilizes a directional `1px` inner glow (`inset 0 1px 0 0 rgba(99, 102, 241, 0.25)`).

## Shapes
The shape language adheres to **Level 1 (Soft)** roundedness. It reinforces architectural stability, discipline, and data compactness:
- Core form controls, interactive buttons, badges, and small tiles inherit `0.25rem` (4px).
- Analytical cards, graph viewports, floating modals, and dashboard panels use `rounded-lg` (`0.5rem` / 8px).
- Complex canvas viewports, flyout drawer corners, and intelligence overlays leverage `rounded-xl` (`0.75rem` / 12px).
- Circular rounding (`9999px`) is reserved solely for status indicator dots, telemetry pings, and user identity avatars.

## Components

### Buttons & Executive Triggers
- **Primary Intelligence Action**: Solid `#4F46E5` fill with white text, crisp 4px radius, `0 1px 2px rgba(0, 0, 0, 0.05)` baseline shadow. On hover, shifts to `#4338CA` with an ambient glow.
- **Secondary Command Trigger**: `#FFFFFF` background, `1px solid #CBD5E1` border, `#0F172A` text. Hover shifts border to `#94A3B8` and background to `#F8FAFC`.
- **Ghost & Monospace Utility**: Transparent canvas with `#475569` text, transitioning to `#0F172A` with `rgba(15, 23, 42, 0.04)` fill on hover.

### Status Indicators & Intelligence Chips
- Chips maintain a height of 24px, font style `label-telemetry`, and a 4px corner radius.
- **Accredited / Compliant**: `#ECFDF5` background, `#059669` text, `1px solid #A7F3D0` border, preceded by an emerald telemetry dot.
- **AI Recommendation**: `#ECFEFF` background, `#0891B2` text, `1px solid #A5F3FC` border with a subtle cyan shimmer pulse.
- **Pedagogical Blocker**: `#FFF1F2` background, `#E11D48` text, `1px solid #FECDD3` border.

### Interactive Data Cards & Analytics Containers
- Built on `rounded-lg` geometry with white background and `1px solid #E2E8F0` border.
- Headers are divided from body content by an ultra-thin 1px horizontal rule, featuring title and uppercase JetBrains Mono classification IDs on the opposite axis.
- Hovering over predictive analytics cards transitions the border to `#C7D2FE` (soft indigo highlight).

### Form Controls & Query Inputs
- Inputs feature a persistent 36px height, `1px solid #CBD5E1` border, `#FFFFFF` background, and `0.25rem` radius.
- Active focus invokes a zero-offset ring: `border-color: #4F46E5` accompanied by `box-shadow: 0 0 0 1px #4F46E5`.
- Search bars integrating AI query parsers append an inline cyan-tinted command badge (`⌘K` rendered in `label-code`).

### Checkboxes & Selection Controls
- Checkbox dimensions are strictly 16x16px with a 3px radius. Unchecked state: `#FFFFFF` fill with `1px solid #94A3B8`. Checked state: `#4F46E5` fill with a sharp white checkmark.
- Radio buttons feature a 16x16px circular profile with a centered 6px solid dot on selection.

### Specialized Components
- **Prerequisite Node Graph**: Interactive, canvas-based nodes with 8px radius, displaying course codes in `label-telemetry`, title in `body-sm`, and competency completion status encoded via colored structural borders.
- **Accreditation Matrix Cell**: Dynamic evaluation cell showing live score metrics, hoverable audit citations, and a semantic color bar docked to the left edge (4px width).