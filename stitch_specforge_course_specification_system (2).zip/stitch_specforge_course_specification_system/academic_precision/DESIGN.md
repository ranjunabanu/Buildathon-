---
name: Academic Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#44474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#525f75'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0e1c2f'
  on-primary-container: '#77849c'
  inverse-primary: '#bac7e1'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001c39'
  on-tertiary-container: '#3c86d9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3fe'
  primary-fixed-dim: '#bac7e1'
  on-primary-fixed: '#0e1c2f'
  on-primary-fixed-variant: '#3a475c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#a4c9ff'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#004883'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: 4.25rem
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0.005em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.025em
  code-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  gutter-tablet: 1rem
  margin: 2rem
  margin-mobile: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative, high-clarity interface tailored for higher education curriculum design, accreditation tracking, and syllabus architecture. It bridges academic rigor with modern product velocity, evoking confidence, meticulous organization, and structural clarity.

The aesthetic blends **Modern Corporate** structure with **Swiss Graphic** precision:
- **Atmosphere:** Deep scholarly authority paired with computational agility.
- **Visual Weight:** Data-dense layouts structured through deliberate white space, sharp typographic rhythm, and subtle surface stratification rather than heavy ornament.
- **Emotional Intent:** Reduces cognitive strain during long curricular drafting sessions, instilling trust through unambiguous state signaling and crystalline hierarchy.

## Colors

The palette balances institutional gravitas with precise digital feedback.

### Core Canvas & Structure
- **Primary Canvas:** `#F8FAFC` provides a calm, neutral base that minimizes glare during prolonged usage.
- **Sub-surface & Wells:** `#F1F5F9` is reserved for structural gutters, code blocks, inactive tabs, and nested specification modules.
- **Primary Ink & Base Brand:** `#0B192C` commands headers, key metrics, and dominant navigation blocks.
- **Interactive Blue:** `#2563EB` acts as the primary action and focus indicator, paired with `#60A5FA` for active highlights and focus halos.

### Strict Semantic Color Protocol
Semantic colors must never be used decoratively. They carry absolute regulatory weight:
- **Success / Approved (`#059669` / `#10B981`):** Strictly reserved for accredited specs, validated learning outcomes, and passing compliance checks.
- **Warning / Under Revision (`#D97706` / `#F59E0B`):** Applied exclusively to non-blocking revision requests, pending prerequisites, and incomplete review stages.
- **Critical / Blocker (`#DC2626` / `#EF4444`):** Strictly reserved for broken prerequisite chains, failed compliance validations, missing required credits, and hard blockers.

## Typography

The type scale combines **Plus Jakarta Sans** for expressive, modern authority in headings with **Inter** for neutral, hyper-legible body copy and tabular layout components.

- Headings demand tight tracking (`-0.01em` to `-0.03em`) to anchor complex specification layouts with editorial poise.
- Body text maintains ample vertical proportion to enable long-form syllabus reviews without reader fatigue.
- Labels and status markers leverage increased weight (`600`) and slight positive letter spacing to remain instantly scannable across dense audit grids.

## Layout & Spacing

This design system uses a flexible 12-column responsive layout system tailored for complex workspaces, split-screen inspectors, and data matrices.

### Breakpoints & Canvas Sizing
- **Mobile (< 768px):** 4 columns, single-column workflow stack, margins collapsed to `margin-mobile`.
- **Tablet (768px - 1024px):** 8 columns, collapsible side drawer for tree navigation.
- **Desktop (1025px - 1440px):** 12 columns, fixed dual-pane (Navigation + Workspace).
- **Wide Desktop (> 1440px):** 12 columns pinned to a max content width of `1680px`, supporting three concurrent panels (Course Tree + Specification Editor + Real-time Accreditation Inspector).

### Spacing Discipline
The spacing scale enforces strict geometric rhythm:
- Spacing between related form fields and metadata labels uses `space-xs` and `space-sm`.
- Padding within cards, modular sections, and container cards relies on `space-md` and `space-lg`.
- Major macro sections and module demarcations use `space-xl`.

## Elevation & Depth

Visual depth is achieved through layered tonal surfaces and ultra-crisp border strokes, avoiding noisy, diffuse dropshadows that clutter dense academic views.

### Surface Hierarchy
1. **Base Floor (`#F8FAFC`):** Primary canvas underpinning entire layouts.
2. **Structural Recesses (`#F1F5F9`):** Sub-toolbars, module drawers, and data table headers.
3. **Elevated Panels (`#FFFFFF`):** High-priority working cards, forms, and curriculum nodes. Every elevated white card carries an exact `1px` structural outline of `#E2E8F0`.
4. **Active/Overlay Surfaces (`#FFFFFF`):** Modals, context menus, and autocomplete dropdowns.

### Shadow Specifications
- **Level 0 (Flat):** `border: 1px solid #E2E8F0; box-shadow: none;`
- **Level 1 (Card Default):** `border: 1px solid #E2E8F0; box-shadow: 0 1px 3px 0 rgba(11, 25, 44, 0.04), 0 1px 2px -1px rgba(11, 25, 44, 0.04);`
- **Level 2 (Card Hover / Inspector Panel):** `border: 1px solid #CBD5E1; box-shadow: 0 4px 6px -1px rgba(11, 25, 44, 0.06), 0 2px 4px -2px rgba(11, 25, 44, 0.04);`
- **Level 3 (Modal / Flyout Menu):** `border: 1px solid #CBD5E1; box-shadow: 0 20px 25px -5px rgba(11, 25, 44, 0.1), 0 8px 10px -6px rgba(11, 25, 44, 0.06);`

## Shapes

The geometric architecture relies on **Level 2 (Rounded)** with purposeful variation to separate large structural containers from small functional controls:

- **Large Structural Surfaces & Cards:** Implement `rounded-xl` (`1.5rem` / `24px`) to create an inviting, polished container silhouette.
- **Inner Modules & Grouped Blocks:** Implement `rounded-lg` (`1rem` / `16px`).
- **Interactive Controls (Buttons, Inputs, Selects):** Implement standard rounded geometry (`0.5rem` / `8px`) to ensure compact, tactile feel and alignment with dense content.
- **Status Tags, Badges & Chips:** Implement full pill rounding (`9999px`) to immediately distinguish categorical indicators from actionable buttons.

## Components

### Buttons
- **Primary:** Background `#0B192C`, text `#FFFFFF`, border radius `0.5rem`. On hover: `#1E293B`. Focus state: `2px` ring in `#2563EB` with `2px` offset.
- **Secondary / Action:** Background `#2563EB`, text `#FFFFFF`. On hover: `#1D4ED8`.
- **Outline:** Background `#FFFFFF`, text `#0B192C`, border `1px solid #CBD5E1`. On hover: background `#F1F5F9`.
- **Destructive:** Background `#DC2626`, text `#FFFFFF`. On hover: `#B91C1C`.

### Cards & Curriculum Modules
- **Container:** Pure `#FFFFFF` background, `rounded-xl`, subtle border `1px solid #E2E8F0`, Level 1 shadow.
- **Header:** Delimited by a bottom border `1px solid #F1F5F9`, internal padding `1.25rem 1.5rem`.
- **Validation State Cards:** Border switches dynamically based on regulatory health (e.g., `1.5px solid #10B981` on valid state; `1.5px solid #EF4444` on blocker).

### Chips & Semantic Badges
- Strict pill silhouette (`rounded-full`), `0.25rem 0.625rem` padding, `label-sm` font.
- **Approved/Accredited:** Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`.
- **Needs Revision:** Background `#FFFBEB`, text `#92400E`, border `1px solid #FDE68A`.
- **Blocked/Non-compliant:** Background `#FEF2F2`, text `#991B1B`, border `1px solid #FECACA`.
- **Informational/Draft:** Background `#F8FAFC`, text `#475569`, border `1px solid #E2E8F0`.

### Form Controls & Input Fields
- **Default State:** Background `#FFFFFF`, border `1px solid #CBD5E1`, text `#0B192C`, placeholder `#94A3B8`, radius `0.5rem`, padding `0.625rem 0.875rem`.
- **Focus State:** Border `#2563EB`, box-shadow `0 0 0 3px rgba(37, 99, 235, 0.15)`, outline none.
- **Invalid State:** Border `#DC2626`, box-shadow `0 0 0 3px rgba(220, 38, 38, 0.15)`.

### Checkboxes & Radio Buttons
- Width/Height `1.125rem`, radius `0.25rem` (checkbox) or `rounded-full` (radio).
- Inactive: border `1.5px solid #94A3B8`, background `#FFFFFF`.
- Checked: border `#2563EB`, background `#2563EB` with white checkmark/dot indicator.

### Course Specification Components
- **Prerequisite Tree Node:** Card with nested indentations, featuring status badge at top right and credit weight in `code-sm` font.
- **Outcome Alignment Matrix:** Data-dense table row with `#F8FAFC` zebra striping on alternate levels, inline validation checks, and sticky column headers anchored with a `1px solid #CBD5E1` lower divider.